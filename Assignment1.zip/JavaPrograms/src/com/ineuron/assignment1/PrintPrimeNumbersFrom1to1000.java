package com.ineuron.assignment1;

public class PrintPrimeNumbersFrom1to1000 {

	public static void main(String[] args) {

		System.out.println("Prime Numbers From 1 - 1000 :");

		for (int i = 1; i <= 1000; i++) {
			int factor = 0;
			for (int j = 1; j <= 1000; j++) {
				if (i % 1 == 0 && i % j == 0)
					factor++;
			}
			if (factor == 2)
				System.out.println(i);
		}
	}
}
