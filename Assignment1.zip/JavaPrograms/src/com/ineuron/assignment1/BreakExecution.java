package com.ineuron.assignment1;

import java.util.Scanner;

public class BreakExecution {
	public static void main(String[] args) {
		System.out.println("Enter input value:");
		try (Scanner sc = new Scanner(System.in)) {
			while (true) {
				int number = sc.nextInt();
				if (number == 85) {
					System.out.println("End of Execution");
					break;
				}
			}

		}
	}
}
