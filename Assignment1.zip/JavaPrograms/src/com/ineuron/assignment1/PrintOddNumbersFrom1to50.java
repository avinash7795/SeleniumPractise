package com.ineuron.assignment1;

public class PrintOddNumbersFrom1to50 {

	public static void main(String[] args) {

		System.out.println("Evern Numbers From 1 - 200 :");
		for (int i = 1; i <=200; i++) {
			if (i % 2 == 0)
				System.out.println(i);
		}
	}

}
