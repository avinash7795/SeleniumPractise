package com.ineuron.assignment1;

public class AvgOf5Numbers {

	public static void main(String[] args) {
		int a = 10, c = 111, d = 8989, e = 7876;
		double b = 90.78;

		double average = (a + b + c + d + e)/5;
		

		System.out.println("Average of five numbers : 10,90.78,111,8989,7876 is " + average);

	}

}
