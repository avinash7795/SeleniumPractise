package com.ineuron.assignment1;

public class SumOf5Numbers {

	public static void main(String[] args) {
		int a = 10, c = 111, d = 8989, e = 7876;
		double b = 90.78;

		double total = a + b + c + d + e;

		System.out.println("Sum of five numbers : 10,90.78,111,8989,7876 is " + total);

	}

}
