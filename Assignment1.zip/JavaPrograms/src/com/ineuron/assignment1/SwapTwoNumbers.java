package com.ineuron.assignment1;

public class SwapTwoNumbers {

	public static void main(String[] args) {

		int a=10, b=20, temp=0;
		temp=a;
		a=b;		
		b=temp;
		System.out.println("a =" +a+" and " + "b="+b );
	}
}
