package com.ineuron.assignment1;

import java.util.Scanner;

public class BreakExecutionSelenium {

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			while (true) {
				System.out.println("Enter a string: ");
				String str = sc.nextLine();
				if (str == "Selenium" || str.equals("Selenium")) {
					System.out.println("End of Execution");
					break;
				}
			}
		}
	}
}